#ifndef As_h
#define As_h

int FA1(int **maze, int l, int c, int lin, int col);
int FA2(int **maze, int l, int c, int lin, int col);
int FA3(int **maze, int l, int c, int lin, int col);
int FA4(int **maze, int l, int c, int lin, int col);
int FA5(int **maze, int l, int c, int lin, int col);
int FA6(int **maze, int l, int c, int lin, int col, int l2, int c2);

#endif